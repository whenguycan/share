package moe.atalanta.mnist;

import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author WANG
 * @date 2018/9/19 18:14
 */
@RestController
public class MnistController {

    @RequestMapping("/test")
    public Object test(){
        MultiLayerNetwork net = MnistClassifier.getNet();
        if(net != null) {
            try {
                return net.evaluate(MnistClassifier.getDataSetIter()).classCount(0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "ok";
    }

}
