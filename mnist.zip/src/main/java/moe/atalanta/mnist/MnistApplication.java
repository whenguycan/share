package moe.atalanta.mnist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MnistApplication {

	public static void main(String[] args) {
		MnistClassifier.initNet();
		SpringApplication.run(MnistApplication.class, args);
	}

}
