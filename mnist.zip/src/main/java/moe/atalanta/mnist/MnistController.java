package moe.atalanta.mnist;

import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.json.JSONObject;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author WANG
 * @date 2018/9/19 18:14
 */
@RestController
public class MnistController {

    @RequestMapping("/test")
    public Object test() {
        MultiLayerNetwork net = MnistClassifier.getNet();
        if (net != null) {
            try {
                INDArray array0 = MnistClassifier.getDataSetIter("55.png").next().getFeatureMatrix();
                INDArray array1 = MnistClassifier.getDataSetIter("5.png").next().getFeatureMatrix();
                JSONObject json = new JSONObject();
                json.put("arr0", net.predict(array0));
                json.put("arr1", net.predict(array1));
                return json.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "ok";
    }

}
