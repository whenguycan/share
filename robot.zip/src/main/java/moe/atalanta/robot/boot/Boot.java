package moe.atalanta.robot.boot;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

/**
 * @author WANG
 * @date 2018/8/25 10:12
 */
public class Boot {

    public static void main(String[] args) {
        new Boot().go();
    }

    private final int[] roles = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

    // 每一步操作都应该确保该步操作已经正确执行，否则将持续操作并检测
    public void go() {
        try {
            initRobot();
            for (int i = 0, len = roles.length; i < len; i++) {
                selectRole(roles[i]);
                new MapWalker().walk();
            }
        } catch (AWTException e) {
            e.printStackTrace();
            System.out.println("create robot error");
            System.exit(0);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("system run error, exit");
            System.exit(0);
        }
    }

    private void selectRole(int roleIdx) {
        // 左键点击对应角色
        // 点击开始按钮
        // 检查是否进入角色主界面
    }

    class MapWalker {

        public void walk() {
            if (checkTired()) {
                moveToMapOut();
                selectMap();
            }
            while (true) {
                walk1();
                walk2();
                walk3();
                walk4();
                walk5();
                walk6();
                walk7();
                if (!checkTired())
                    break;
            }
            goToSelectRoleWindow();
        }

        private void goToSelectRoleWindow() {
            // esc
            // 点击选择角色
        }

        private void walk1() {
            // 判断是否进入
            // 召唤BB
            // 等待
            // 检查是否开门
            // 移动到下一图门口
        }

        private void walk2() {
            // 判断是否进入
            // 等待
            // 检查是否开门
            // 移动到下一图门口
        }

        private void walk3() {
            // 3~6与2相同
            // 下一图位置不同
        }

        private void walk4() {

        }

        private void walk5() {

        }

        private void walk6() {

        }

        private void walk7() {
            // 检测是否通关
            // 检查疲劳
            // 有疲劳F10/疲劳F12
        }

        private void selectMap() {
            // 选中格蓝迪
            // 选择难度
            // 双击进入地图
        }

        private void moveToMapOut() {
            // 按键N打开地图，左键点击格蓝迪外边的位置
        }

        private boolean checkTired() {
            return false;
        }

    }

    private String shotscreen(Rectangle rectangle){
        File root = new File("c:/desktop");
        File file = new File(root, "screenshot_" + System.currentTimeMillis() + ".png");
        BufferedImage im = robot.createScreenCapture(rectangle);
        try {
            ImageIO.write(im, "png", file);
            return file.getPath();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void mouseMove(int x, int y) {
        robot.mouseMove(x, y);
    }

    private void leftClick() {
        robot.mousePress(KeyEvent.BUTTON1_DOWN_MASK);
        sleep();
        robot.mouseRelease(KeyEvent.BUTTON1_DOWN_MASK);
    }

    private void rightClick() {
        robot.mousePress(KeyEvent.BUTTON3_DOWN_MASK);
        sleep();
        robot.mouseRelease(KeyEvent.BUTTON3_DOWN_MASK);
    }

    private void keyClick(int keyEvent) {
        robot.keyPress(keyEvent);
        sleep();
        robot.keyRelease(keyEvent);
    }

    private void sleep() {
        sleep(198, 200);
    }

    private void sleep(int millis, int seed) {
        sleep(millis + new Random(seed).nextInt());
    }

    private void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private Robot robot = null;

    private void initRobot() throws Exception {
        robot = new Robot();
    }

    public void test() {
        try {
            Robot robot = new Robot();
            Thread.sleep(1200);
            BufferedImage screenshot = robot.createScreenCapture(new Rectangle(0, 0, 300, 300));
            String filename = "C:\\Users\\Administrator\\Desktop\\screenshot" + String.valueOf(Math.random()).replace(".", "") + ".png";
            ImageIO.write(screenshot, "png", new FileOutputStream(filename));
        } catch (AWTException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 1、选择人物界面
     * 2、人物站街界面
     * 3、人物站街打开地图界面
     * 4、地下城选择界面
     * 5、地图1~地图7
     * 6、通关结算界面
     */

}
