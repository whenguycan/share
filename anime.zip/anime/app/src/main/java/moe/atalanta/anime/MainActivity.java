package moe.atalanta.anime;

import android.os.Bundle;
import android.widget.TextView;

import moe.atalanta.anime.activity.AnimeActivity;
import moe.atalanta.anime.comm.BaseActivity;

public class MainActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		TextView tv = findViewById(R.id.tv_main);
		tv.setOnClickListener(v -> startActivity(AnimeActivity.class));

	}
}
