package moe.atalanta.anime.enums;

/**
 * Created by wang on 2018/11/1.
 */

public enum AnimeSeason implements IEnum {

	One("1", "第一季"),
	Two("2", "第二季"),
	Thr("3", "第三季"),
	Fou("4", "第四季"),
	Fiv("5", "第五季"),
	Six("6", "第六季"),

	Ex("101", "EX特典"),
	Sp("102", "SP特典"),

	Film("103", "剧场版");

	private String code;
	private String text;

	AnimeSeason(String code, String text){
		this.code = code;
		this.text = text;
	}

	public String code() {
		return null;
	}

	public String text() {
		return null;
	}

	public int codeInt() {
		try {
			return Integer.parseInt(code);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return -1;
	}

}
