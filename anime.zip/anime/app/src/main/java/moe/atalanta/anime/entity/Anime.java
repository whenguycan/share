package moe.atalanta.anime.entity;

import com.github.promeg.pinyinhelper.Pinyin;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;

import java.io.Serializable;
import org.greenrobot.greendao.annotation.Generated;

/**
 * Created by wang on 2018/11/1.
 */

@Entity
public class Anime implements Serializable {
	private static final long serialVersionUID = -6292893426662295562L;

	@Id
	private long id;
	private int state;
	private long createTime;
	private long updateTime;

	private String title;
	private String spell;
	private int curr;
	private int total;

	private int serial;
	private int season;

	public static Anime newInstance(String title, int curr, int total, int serial, int season){
		Anime anime = new Anime();
		anime.setCreateTime(System.currentTimeMillis());
		anime.setUpdateTime(anime.getCreateTime());
		anime.setTitle(title);
		anime.buildSpell();
		anime.setCurr(curr);
		anime.setTotal(total);
		anime.setSerial(serial);
		anime.setSeason(season);
		return anime;
	}

	private void buildSpell(){
		String spell = "";
		if(title != null){
			if(title.length() > 0){
				char c = title.charAt(0);
				spell += Pinyin.isChinese(c) ? Pinyin.toPinyin(c) : String.valueOf(c);
			}
			if(title.length() > 1){
				char c = title.charAt(1);
				spell += Pinyin.isChinese(c) ? Pinyin.toPinyin(c) : String.valueOf(c);
			}
		}
		if(!spell.isEmpty())
			this.spell = spell;
	}

	@Generated(hash = 1749115368)
	public Anime(long id, int state, long createTime, long updateTime, String title,
			String spell, int curr, int total, int serial, int season) {
		this.id = id;
		this.state = state;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.title = title;
		this.spell = spell;
		this.curr = curr;
		this.total = total;
		this.serial = serial;
		this.season = season;
	}

	@Generated(hash = 1101169224)
	public Anime() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getState() {
		return this.state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}

	public long getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(long updateTime) {
		this.updateTime = updateTime;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getCurr() {
		return this.curr;
	}

	public void setCurr(int curr) {
		this.curr = curr;
	}

	public int getTotal() {
		return this.total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getSerial() {
		return this.serial;
	}

	public void setSerial(int serial) {
		this.serial = serial;
	}

	public int getSeason() {
		return this.season;
	}

	public void setSeason(int season) {
		this.season = season;
	}

	public String getSpell() {
		return this.spell;
	}

	public void setSpell(String spell) {
		this.spell = spell;
	}

	

}
