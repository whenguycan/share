package moe.atalanta.anime.enums;

/**
 * Created by wang on 2018/11/1.
 */

public interface IEnum {

	String code();
	String text();
	int codeInt();

}
