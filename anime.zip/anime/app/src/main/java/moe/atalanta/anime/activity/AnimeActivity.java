package moe.atalanta.anime.activity;

import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import moe.atalanta.anime.R;
import moe.atalanta.anime.comm.BaseActivity;
import moe.atalanta.anime.entity.Anime;

public class AnimeActivity extends BaseActivity {

	ListView lv;
	SwipeRefreshLayout srl;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_anime);

		lv = findViewById(R.id.lv);

		srl = findViewById(R.id.srl);
		srl.setOnRefreshListener(() -> new Handler().postDelayed(() -> {
			reloadListView();
			srl.setRefreshing(false);
		}, 1000));

	}

	private void reloadListView(){
		final List<Anime> list = genAnimeList();
		lv.setAdapter(new ArrayAdapter<Anime>(getContext(), R.layout.anime_item, list){
			@NonNull
			@Override
			public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
				View view = getLayoutInflater().inflate(R.layout.anime_item, null);
				TextView tv = view.findViewById(R.id.tv_title);
				tv.setText(list.get(position).getTitle());
				return view;
			}
		});
	}

	private List<Anime> genAnimeList(){
		List<Anime> list = new ArrayList<>();
		list.add(Anime.newInstance("秒5", 1, 12, 1, 1));
		list.add(Anime.newInstance("Clannad", 1, 12, 1, 1));
		return list;
	}

}
