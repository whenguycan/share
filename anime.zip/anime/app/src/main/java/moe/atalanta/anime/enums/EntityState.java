package moe.atalanta.anime.enums;

/**
 * Created by wang on 2018/11/1.
 */

public enum EntityState implements IEnum {

	Normal("0", "正常"),
	Delete("1", "删除");

	private String code;
	private String text;

	EntityState(String code, String text){
		this.code = code;
		this.text = text;
	}

	public String code(){
		return code;
	}

	public String text(){
		return text;
	}

	public int codeInt(){
		try {
			return Integer.parseInt(code);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return -1;
	}

}
